﻿/*using Data_Access_Layer.Data;
using Data_Access_Layer.IRepositories;
using Data_Access_Layer.Models;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace Data_Access_Layer.Repositories
{
    public class AdminRepository : IAdminRepository
    {
        private readonly AuctionDbContext _context;

        public AdminRepository(AuctionDbContext context)
        {
            _context = context;
        }

        public async Task<User> GetUserById(int userId)
        {
            return await _context.Users.FindAsync(userId);
        }

        public async Task UpdateUser(User user)
        {
            _context.Entry(user).State = EntityState.Modified;
            await _context.SaveChangesAsync();
        }
    }
}
*/