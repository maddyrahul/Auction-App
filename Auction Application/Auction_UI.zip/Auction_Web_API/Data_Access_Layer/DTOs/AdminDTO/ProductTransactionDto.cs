﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Data_Access_Layer.DTOs.AdminDTO
{
    public class ProductTransactionDto
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public bool IsBuyer { get; set; }
        public DateTime TransactionDate { get; set; }
        public decimal Amount { get; set; }
    }
}
