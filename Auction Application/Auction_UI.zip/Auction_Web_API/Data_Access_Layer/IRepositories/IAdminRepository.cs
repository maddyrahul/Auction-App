﻿/*using Data_Access_Layer.Models;
using Data_Access_Layer.DTOs.AdminDTO;

namespace Data_Access_Layer.IRepositories
{
    public interface IAdminRepository
    {
        Task<User> GetUserById(int userId);
        Task UpdateUser(User user);
 
    }
}
*/