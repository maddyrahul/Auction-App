﻿/*



using Business_Layer.Sevices.Interfaces;
using Data_Access_Layer.DTOs.AdminDTO;
using Data_Access_Layer.IRepositories;
using System;
using System.Threading.Tasks;

namespace Business_Layer.Sevices
{
    public class AdminService : IAdminService
    {
        private readonly IAdminRepository _adminRepository;

        public AdminService(IAdminRepository adminRepository)
        {
            _adminRepository = adminRepository;
        }

        public async Task<bool> BanUser(int userId)
        {
            var user = await _adminRepository.GetUserById(userId);
            if (user != null)
            {
                user.IsBanned = true;
                // You might want to add an additional property for permanent bans
                // user.IsPermanentlyBanned = true;
                await _adminRepository.UpdateUser(user);
                return true;
            }
            return false;
        }
    }
}
*/