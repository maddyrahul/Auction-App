﻿using Data_Access_Layer.DTOs;


namespace Business_Layer.Sevices.Interfaces
{
    public interface IBidService
    {
        Task<IEnumerable<BidDto>> GetAllBids();
        Task<BidDto> GetBidById(int id);
        Task<BidDto> CreateBid(BidDto bidDto);
        Task<BidDto> UpdateBid(int id, BidDto bidDto);
        Task DeleteBid(int id);
    }
}
