﻿/*using Business_Layer.Sevices.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Presentation_Layer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IAdminService _adminService;

        public AdminController(IAdminService adminService)
        {
            _adminService = adminService;
        }

        [HttpPost("users/{userId}/ban")]
        public async Task<IActionResult> BanUser(int userId)
        {
            var userExists = await _adminService.BanUser(userId);
            if (!userExists)
            {
                return NotFound(new { message = "User not found." });
            }
            return NoContent();
        }
    }
}
*/