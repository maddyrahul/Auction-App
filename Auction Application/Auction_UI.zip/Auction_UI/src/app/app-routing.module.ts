import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './components/user/user.component';
import { AuctionComponent } from './components/auction/auction.component';
import { BidComponent } from './components/bid/bid.component';
import { LoginComponent } from './components/login/login.component';
import { AuctionFormComponent } from './components/auction-form/auction-form.component';
import { PlaceBidComponent } from './components/place-bid/place-bid.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { AuctionListComponent } from './components/auction-list/auction-list.component';
import { AuthGuard } from './guards/auth.guard';

const routes: Routes = [
  { path: '', redirectTo: '/auctions', pathMatch: 'full' },
  { path: 'users', component: UserComponent ,canActivate: [AuthGuard] , data: { role: 'Admin' }},
  { path: 'auctions', component: AuctionComponent },
  { path: 'bids', component: BidComponent ,canActivate: [AuthGuard] , data: { role: 'Admin' }},
  { path: 'login',component: LoginComponent},
  { path: 'create-auction', component: AuctionFormComponent,canActivate: [AuthGuard] , data: { role: 'User' } },
  { path: 'place-bid/:id', component: PlaceBidComponent ,canActivate: [AuthGuard] , data: { role: 'User' }},
  { path: 'edit-user/:id', component: EditUserComponent ,canActivate: [AuthGuard] , data: { role: 'Admin' }},
  { path: 'auction-list', component: AuctionListComponent ,canActivate: [AuthGuard] , data: { role: 'Admin' }},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
