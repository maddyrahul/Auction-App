import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { Auction } from '../Models/Auction';

@Injectable({
  providedIn: 'root'
})
export class AuctionService {

  private apiUrl = 'https://localhost:7210/api/Auctions'; // Adjust the URL as needed

  constructor(private http: HttpClient) {}

  getAllAuctions(): Observable<Auction[]> {
    return this.http.get<Auction[]>(this.apiUrl);
  }

  getAuctionById(id: number): Observable<Auction> {
    return this.http.get<Auction>(`${this.apiUrl}/${id}`);
  }

  createAuction(auctionDto: Auction): Observable<Auction> {
    return this.http.post<Auction>(this.apiUrl, auctionDto);
  }

  updateAuction(id: number, auctionDto: Auction): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, auctionDto);
  }

  deleteAuction(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }

  searchAuctions(searchValue: string): Observable<Auction[]> {
    return this.http.get<Auction[]>(`${this.apiUrl}/search?searchValue=${searchValue}`);
  }
}
