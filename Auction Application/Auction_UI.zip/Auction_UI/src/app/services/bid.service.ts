import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Bid } from '../Models/Bid';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class BidService {

  private apiUrl = 'https://localhost:7210/api/Bids'; // Adjust the URL as needed

  constructor(private http: HttpClient) {}

  getAllBids(): Observable<Bid[]> {
    return this.http.get<Bid[]>(this.apiUrl);
  }

  getBidById(id: number): Observable<Bid> {
    return this.http.get<Bid>(`${this.apiUrl}/${id}`);
  }

  createBid(bidDto: Bid): Observable<Bid> {
    return this.http.post<Bid>(this.apiUrl, bidDto);
  }

  updateBid(id: number, bidDto: Bid): Observable<void> {
    return this.http.put<void>(`${this.apiUrl}/${id}`, bidDto);
  }

  deleteBid(id: number): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/${id}`);
  }
}
