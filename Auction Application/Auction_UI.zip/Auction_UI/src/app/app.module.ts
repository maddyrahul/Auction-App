import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './components/user/user.component';
import { AuctionComponent } from './components/auction/auction.component';
import { BidComponent } from './components/bid/bid.component';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { AuctionFormComponent } from './components/auction-form/auction-form.component';
import { PlaceBidComponent } from './components/place-bid/place-bid.component';
import { EditUserComponent } from './components/edit-user/edit-user.component';
import { AuctionListComponent } from './components/auction-list/auction-list.component';

@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AuctionComponent,
    BidComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    AuctionFormComponent,
    PlaceBidComponent,
    EditUserComponent,
    AuctionListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule  ,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
