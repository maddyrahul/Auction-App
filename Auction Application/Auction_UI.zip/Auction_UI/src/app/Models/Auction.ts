export interface Auction {
    auctionId: number;
    productName: string;
    category: string;
    description: string;
    startingPrice: number;
    reservedPrice?: number;
    durationTime: number; // Duration in seconds
    sellerId: number;
    startTime: Date;
    isEnded: boolean;
    endTime: Date;
  }
  