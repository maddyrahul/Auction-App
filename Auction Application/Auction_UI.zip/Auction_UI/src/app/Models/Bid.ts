export interface Bid {
    bidId: number;
    amount: number;
    auctionId: number;
    userId: number;
  }
  