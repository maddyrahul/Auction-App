import { Component, OnInit } from '@angular/core';
import { Auction } from '../../Models/Auction';
import { AuctionService } from '../../services/auction.service';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auction-list',
  templateUrl: './auction-list.component.html',
  styleUrls: ['./auction-list.component.css']
})
export class AuctionListComponent implements OnInit {
  auctions: Auction[] = [];
  searchValue: string = '';

  constructor(private auctionService: AuctionService, public userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.loadAuctions();
  }

  loadAuctions(): void {
    this.auctionService.getAllAuctions().subscribe(auctions => {
      this.auctions = auctions;
    });
  }

  onSearch(): void {
    if (this.searchValue) {
      this.auctionService.searchAuctions(this.searchValue).subscribe(auctions => {
        this.auctions = auctions;
      });
    } else {
      this.loadAuctions();
    }
  }

  deleteAuction(auctionId: number) {
    if (confirm('Are you sure you want to delete this auction?')) {
      this.auctionService.deleteAuction(auctionId).subscribe(() => {
        this.auctions = this.auctions.filter(a => a.auctionId !== auctionId);
      });
    }
  }
}
