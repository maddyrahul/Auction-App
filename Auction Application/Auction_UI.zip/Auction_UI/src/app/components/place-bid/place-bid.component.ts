import { Component } from '@angular/core';
import { BidService } from '../../services/bid.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Bid } from '../../Models/Bid';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-place-bid',
  templateUrl: './place-bid.component.html',
  styleUrl: './place-bid.component.css'
})
export class PlaceBidComponent {
  bidForm: FormGroup;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private bidService: BidService,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private router: Router
  ) {
    this.bidForm = this.fb.group({
      amount: [0, [Validators.required, Validators.min(1)]],
      auctionId: [0, Validators.required],
      userId: [0, Validators.required]
    });
  }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.bidForm.patchValue({
        auctionId: +params['id'],
        userId: parseInt(localStorage.getItem('user_id')!, 10) // Assuming userId is stored in local storage
      });
    });
  }

  onSubmit() {
    if (this.bidForm.valid) {
      this.bidService.createBid(this.bidForm.value).subscribe(
        response => {
          console.log('Bid placed', response);
          this.showSuccessMessage('Bid placed successfully');
        },
        error => {
          console.error('Error placing bid', error);
          this.showErrorMessage(error.error); // Assuming the backend sends the error message in the response body
        }
      );
    } else {
      this.showErrorMessage('Please enter a valid bid amount');
    }
  }

  showErrorMessage(message: string) {
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 2000); // Clear error message after 2 seconds
  }

  showSuccessMessage(message: string) {
    this.successMessage = message;
    setTimeout(() => {
      this.successMessage = '';
      this.router.navigate(['/auctions']); // Redirect to auctions page after 2 seconds
    }, 2000); // Clear success message and redirect after 2 seconds
  }
}
