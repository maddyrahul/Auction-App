import { Component, OnInit } from '@angular/core';
import { Bid } from '../../Models/Bid';
import { BidService } from '../../services/bid.service';
import { UserService } from '../../services/user.service';
import { AuctionService } from '../../services/auction.service';
import { forkJoin } from 'rxjs';

interface ExtendedBid extends Bid {
  username: string;
  productName: string;
}

@Component({
  selector: 'app-bid',
  templateUrl: './bid.component.html',
  styleUrls: ['./bid.component.css']
})
export class BidComponent implements OnInit {
  extendedBids: ExtendedBid[] = [];

  constructor(
    private bidService: BidService,
    private userService: UserService,
    private auctionService: AuctionService
  ) {}

  ngOnInit(): void {
    this.loadBids();
  }

  loadBids(): void {
    this.bidService.getAllBids().subscribe(bids => {
      const observables = bids.map(bid => 
        forkJoin({
          user: this.userService.getUserById(bid.userId),
          auction: this.auctionService.getAuctionById(bid.auctionId)
        })
      );

      forkJoin(observables).subscribe(results => {
        this.extendedBids = bids.map((bid, index) => ({
          ...bid,
          username: results[index].user.username,
          productName: results[index].auction.productName
        }));
      });
    });
  }
}