import { Component, OnInit } from '@angular/core';
import { User } from '../../Models/User';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrl: './edit-user.component.css'
})
export class EditUserComponent implements OnInit{
  user: User = {} as User;
  userId: number = 0;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.userId = +params['id'];
      this.loadUser();
    });
  }

  loadUser(): void {
    this.userService.getUserById(this.userId).subscribe(
      user => {
        this.user = user;
      },
      error => {
        console.error('Error loading user', error);
      }
    );
  }

  onSubmit(): void {
    this.userService.updateUser(this.userId, this.user).subscribe(
      () => {
        console.log('User updated successfully');
        this.router.navigate(['/users']);
      },
      error => {
        console.error('Error updating user', error);
      }
    );
  }
}
