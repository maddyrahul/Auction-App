import { Component, OnInit } from '@angular/core';
import { Auction } from '../../Models/Auction';
import { AuctionService } from '../../services/auction.service';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-auction',
  templateUrl: './auction.component.html',
  styleUrls: ['./auction.component.css']
})
export class AuctionComponent implements OnInit {
  auctions: Auction[] = [];
  searchValue: string = '';

  constructor(
    private auctionService: AuctionService, 
    public userService: UserService, 
    private router: Router
  ) {}

  ngOnInit(): void {
    this.loadAuctions();
  }

  loadAuctions(): void {
    this.auctionService.getAllAuctions().subscribe(auctions => {
      this.auctions = auctions;
    });
  }

  onSearch(): void {
    if (this.searchValue) {
      this.auctionService.searchAuctions(this.searchValue).subscribe(auctions => {
        this.auctions = auctions;
      });
    } else {
      this.loadAuctions();
    }
  }

  placeBid(auctionId: number) {
    if (this.userService.isLoggedIn()) {
      this.router.navigate(['/place-bid', auctionId]);
    } else {
      alert('Please log in to place a bid.');
     
    }
  }
}