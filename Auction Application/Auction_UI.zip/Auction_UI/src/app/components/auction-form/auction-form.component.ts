import { Component } from '@angular/core';
import { Auction } from '../../Models/Auction';
import { AuctionService } from '../../services/auction.service';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-auction-form',
  templateUrl: './auction-form.component.html',
  styleUrl: './auction-form.component.css'
})
export class AuctionFormComponent {
  auctionForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private auctionService: AuctionService,
    private router: Router
  ) {
    this.auctionForm = this.fb.group({
      productName: ['', Validators.required],
      description: ['', Validators.required],
      startingPrice: [0, [Validators.required, Validators.min(0.01)]],
      reservedPrice: [0, [Validators.required, Validators.min(0.01)]],
      durationTime: [0, [Validators.required, Validators.min(1)]],
      category: ['', Validators.required],
      sellerId: [0, Validators.required],
      startTime: [new Date()],
      endTime: [new Date()],
      isEnded: [false]
    });
  }

  ngOnInit(): void {
    this.auctionForm.patchValue({
      sellerId: parseInt(localStorage.getItem('user_id')!, 10)
    });
  }

  onSubmit() {
    if (this.auctionForm.valid) {
      const auction = this.auctionForm.value;
      auction.startTime = new Date();
      auction.endTime = new Date(auction.startTime.getTime() + auction.durationTime * 1000);

      this.auctionService.createAuction(auction).subscribe(
        response => {
          console.log('Auction created', response);
          this.router.navigate(['/auctions']);
        },
        error => {
          console.error('Error creating auction', error);
          this.showErrorMessage('Error creating auction. Please try again.');
        }
      );
    } else {
      this.showErrorMessage('Please fill in all required fields.');
    }
  }

  showErrorMessage(message: string) {
    this.errorMessage = message;
    setTimeout(() => {
      this.errorMessage = '';
    }, 2000); // Clear error message after 2 seconds
  }
}
