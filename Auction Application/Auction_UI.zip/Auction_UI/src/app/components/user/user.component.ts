import { Component, OnInit } from '@angular/core';
import { User } from '../../Models/User';
import { UserService } from '../../services/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrl: './user.component.css'
})
export class UserComponent implements OnInit {
  users: User[] = [];

  constructor(private userService: UserService, private router: Router) {}

  ngOnInit(): void {
    this.loadUsers();
  }

  loadUsers(): void {
    this.userService.getAllUsers().subscribe(users => {
      this.users = users;
      console.log("Users ", this.users);
    });
  }

  // toggleBan(user: User): void {
  //   user.isBanned = !user.isBanned;
  //   this.userService.updateUser(user.userId, user).subscribe(() => {
  //     console.log(`User ${user.username} ${user.isBanned ? 'banned' : 'unbanned'}`);
  //   });
  // }
  toggleBan(user: User): void {
    if (user.role.toLowerCase() === 'admin') {
      alert('Admin users cannot be banned.');
      return;
    }
    
    user.isBanned = !user.isBanned;
    this.userService.updateUser(user.userId, user).subscribe(() => {
      console.log(`User ${user.username} ${user.isBanned ? 'banned' : 'unbanned'}`);
    });
  }
  editUser(userId: number): void {
    this.router.navigate(['/edit-user', userId]);
  }

  deleteUser(userId: number): void {
    if (confirm('Are you sure you want to delete this user?')) {
      this.userService.deleteUser(userId).subscribe(() => {
        this.users = this.users.filter(user => user.userId !== userId);
        console.log(`User with ID ${userId} deleted`);
      });
    }
  }
}
